const Product = require('./model/product.model.js'); 


const getProducts = async(req,res)=>{
    try {
        const product = await product.find({});
        res.status(200).json(Product)
    } catch (error) {
        res.status(500).json({message:error.message})
    }
}

const getProduct = async(req,res)=>{
    try {
        const product = await product.findById(id);
        res.status(200).json(Product)
    } catch (error) {
        res.status(500).json({message:error.message})
    }
}

const createProduct = async(req,res)=>{
   try {
           const product = await Product.create(req.body); // Use the already imported model
           res.status(201).json(product);
       } catch (error) {
           console.error(error);
           res.status(500).json({ message: "Internal Server Error" });
       }
}

const updateProduct = async(req,res)=>{
    try {
        const {id} = req.params;
        const product = await Product.findByIdAndUpdate(id, req.body)

        if(!product){
            res.status(404).json({message:"the product not found"})
        }
    
        const UpdatedProduct = await Product.findById(id)
        res.status(200).json(UpdatedProduct)
     } catch (error) {
        res.status(500).json({message:error.message})
     }
}

const deleteProduct = async (req,res)=>{
     try {
            const {id} = req.params;
            const DeleteProduct = await Product.findByIdAndDelete(id);
            if(!Product){
              return res.status(404).json({message:"product not found"})
            }
        } catch (error) {
         res.status(500).json({message:error.message})
        }
}
module.exports = {
    getProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct
}